// Verification for results webhooks MayaMaya POSTs to your endpoint.
//
// You do NOT need a separate webhook secret. The signing key is derived from the
// Service API Key you already hold: `sha256(apiKey)`. Nothing extra to provision,
// store, or rotate -- and because sha256 is one-way, the signing key can never be
// turned back into your API key.
//
// If you're not using this SDK (different language, no dependency), the whole
// scheme is these four lines:
//
//   signingKey = sha256_hex(YOUR_API_KEY)
//   t, v1      = parse "t=<unix>,v1=<hex>" from the x-catenate-signature header
//   expected   = hmac_sha256_hex(signingKey, t + "." + RAW_REQUEST_BODY)
//   valid      = constant_time_equals(expected, v1) and abs(now - t) < tolerance
//
// RAW_REQUEST_BODY means the exact bytes we sent. If your framework parsed the JSON
// and you re-serialize it, key order or whitespace can differ and the signature
// will not match -- see the note in the README about express.raw().

import { createHash, createHmac, timingSafeEqual } from "node:crypto";

export const SIGNATURE_HEADER = "x-catenate-signature";
export const KEY_ID_HEADER = "x-catenate-key-id";
export const EVENT_ID_HEADER = "x-catenate-event-id";
export const EVENT_TYPE_HEADER = "x-catenate-event-type";

// Rejects deliveries whose timestamp is too old to be genuine, so a captured
// request can't be replayed against you indefinitely. Five minutes is generous
// enough for clock skew between your host and ours.
export const DEFAULT_TOLERANCE_SECONDS = 300;

export class MayamayaWebhookError extends Error {
  constructor(message) {
    super(message);
    this.name = "MayamayaWebhookError";
  }
}

/** The HMAC key for a given Service API Key. Exported mainly so you can test against it. */
export const webhookSigningKey = (apiKey) => createHash("sha256").update(apiKey).digest("hex");

const parseSignatureHeader = (header) => {
  const parts = String(header || "")
    .split(",")
    .map((piece) => piece.trim().split("="));
  const fields = Object.fromEntries(parts.filter((p) => p.length === 2));
  if (!fields.t || !fields.v1) {
    throw new MayamayaWebhookError(`malformed ${SIGNATURE_HEADER} header`);
  }
  return { timestamp: Number(fields.t), signature: fields.v1 };
};

const constantTimeEquals = (a, b) => {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
};

const headerValue = (headers, name) => {
  if (!headers) return undefined;
  // Works with a plain object, Node's lowercased req.headers, and fetch Headers.
  if (typeof headers.get === "function") return headers.get(name) ?? undefined;
  const direct = headers[name];
  if (direct !== undefined) return direct;
  const match = Object.keys(headers).find((k) => k.toLowerCase() === name);
  return match ? headers[match] : undefined;
};

/**
 * Verifies a delivery and returns the parsed event. Throws MayamayaWebhookError if
 * the signature, timestamp, or body doesn't check out -- never returns a partially
 * trusted result.
 *
 * @param {object} args
 * @param {string|Buffer} args.payload - The RAW request body, exactly as received.
 * @param {object|Headers} [args.headers] - The request headers (simplest option).
 * @param {string} [args.signature] - The x-catenate-signature value, if you'd rather pass it directly.
 * @param {string|string[]} args.apiKey - Your Service API Key. Pass an array while rotating keys: any match verifies.
 * @param {number} [args.toleranceSeconds]
 * @returns {{id: string, type: string, createdAt: string, orgId: string, data: object}}
 */
export function constructEvent({ payload, headers, signature, apiKey, toleranceSeconds = DEFAULT_TOLERANCE_SECONDS }) {
  const apiKeys = (Array.isArray(apiKey) ? apiKey : [apiKey]).filter(Boolean);
  if (!apiKeys.length) throw new MayamayaWebhookError("apiKey is required to verify a webhook");

  const rawBody = Buffer.isBuffer(payload) ? payload.toString("utf8") : payload;
  if (typeof rawBody !== "string" || !rawBody) {
    throw new MayamayaWebhookError("payload must be the raw request body (string or Buffer)");
  }

  const header = signature ?? headerValue(headers, SIGNATURE_HEADER);
  if (!header) throw new MayamayaWebhookError(`missing ${SIGNATURE_HEADER} header`);

  const { timestamp, signature: provided } = parseSignatureHeader(header);
  if (!Number.isFinite(timestamp)) throw new MayamayaWebhookError("signature timestamp is not a number");

  const ageSeconds = Math.abs(Date.now() / 1000 - timestamp);
  if (ageSeconds > toleranceSeconds) {
    throw new MayamayaWebhookError(`signature timestamp is outside the ${toleranceSeconds}s tolerance (off by ${Math.round(ageSeconds)}s)`);
  }

  const signedPayload = `${timestamp}.${rawBody}`;
  const matched = apiKeys.some((key) =>
    constantTimeEquals(createHmac("sha256", webhookSigningKey(key)).update(signedPayload).digest("hex"), provided)
  );
  if (!matched) throw new MayamayaWebhookError("signature does not match");

  try {
    return JSON.parse(rawBody);
  } catch {
    throw new MayamayaWebhookError("signature verified but the body is not valid JSON");
  }
}

/** Boolean form of constructEvent, for when you only want to gate on validity. */
export function verifyWebhookSignature(args) {
  try {
    constructEvent(args);
    return true;
  } catch {
    return false;
  }
}
