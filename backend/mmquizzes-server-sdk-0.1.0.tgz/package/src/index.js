// Server-side SDK for Mayamaya Quizzes. This is the only place that should ever
// hold your Service API Key -- never ship it to the browser. Pair with
// mmquizzes-embed-sdk (browser) for the popup side of the integration.
//
// See ../README.md for setup, and the "Mayamaya Quizzes" section of the developer
// documentation for the underlying HTTP API this wraps.

import { constructEvent } from "./webhooks.js";

export { MayamayaWebhookError, constructEvent, verifyWebhookSignature, webhookSigningKey } from "./webhooks.js";

// The MayaMaya API. `baseUrl` overrides it, which is only useful when pointing at
// a local backend during development -- there is no second public environment.
const DEFAULT_BASE_URL = "https://developers-api-01.mayamaya.ai";
const INITIATE_PATH = "/api/v1/embed/mmQuizzes/initiate";
const VERIFY_KEY_PATH = "/api/v1/embed/verify-key";
const MMQUIZZES_BASE = "/api/v1/embed/mmQuizzes";

// User ids are yours and we never constrain their shape, so they can legitimately
// contain "/" or "#". Encoding is not optional.
const userPath = (userId, suffix) => `${MMQUIZZES_BASE}/users/${encodeURIComponent(userId)}${suffix}`;

const requireUserId = (userId, method) => {
  if (!userId || typeof userId !== "string") {
    throw new TypeError(`MayamayaQuizClient#${method}: userId is required`);
  }
};

export class MayamayaQuizError extends Error {
  constructor(status, message, body) {
    super(message);
    this.name = "MayamayaQuizError";
    this.status = status;
    this.body = body;
  }
}

export class MayamayaQuizClient {
  #apiKey;
  #baseUrl;
  #defaultUserType;
  #defaultDailyLimit;
  #defaultResultsWebhookUrl;
  #defaultEmbedOrigin;

  /**
   * @param {object} options
   * @param {string} options.apiKey - Your Service API Key (Dashboard -> API Keys). Required.
   * @param {string} [options.baseUrl] - Override the MayaMaya API host. Rarely needed; for pointing at a local backend.
   * @param {string} [options.resultsWebhookUrl] - Where completed results are POSTed. Required on every initiate() call, so set it here once unless it varies per user.
   * @param {"Professional"|"Student"} [options.userType] - Default for every initiate() call; per-call `options.userType` overrides it.
   * @param {{cycleCount:number, windowHours:number}} [options.dailyLimit] - Default for every initiate() call; per-call overrides it. Caps completed RESULT CYCLES per window, not questions.
   * @param {string} [options.embedOrigin] - Origin of your page that will frame the quiz (embedded mode). Default for every initiate() call; per-call overrides it.
   */
  constructor(options = {}) {
    const { apiKey, baseUrl = DEFAULT_BASE_URL, userType, dailyLimit, resultsWebhookUrl, embedOrigin } = options;
    if (!apiKey || typeof apiKey !== "string") {
      throw new TypeError("MayamayaQuizClient: options.apiKey is required (your Service API Key)");
    }
    this.#apiKey = apiKey;
    this.#baseUrl = baseUrl.replace(/\/+$/, "");
    this.#defaultUserType = userType;
    this.#defaultDailyLimit = dailyLimit;
    this.#defaultResultsWebhookUrl = resultsWebhookUrl;
    this.#defaultEmbedOrigin = embedOrigin;
  }

  /**
   * Initiates a quiz session for the given end user and returns a single-use quiz
   * link. Call this fresh on every "take the quiz" click from your own backend
   * route -- never cache or reuse the returned link (see README).
   *
   * `userType` and `dailyLimit` (from the constructor defaults, or passed here)
   * only take effect on a user's FIRST initiate call ever -- they're frozen on
   * that user's account after that, by design, so a user's question pool and
   * pacing never change mid-assessment.
   *
   * `resultsWebhookUrl` is REQUIRED and is NOT frozen -- every call updates where
   * that user's results will be delivered, so moving your endpoint takes effect
   * for in-flight users too.
   *
   * @param {string} userId - Your own identifier for this end user. Stable and unique per user.
   * @param {object} [options]
   * @param {string} [options.resultsWebhookUrl] - Overrides the constructor default for this user.
   * @param {"Professional"|"Student"} [options.userType]
   * @param {{cycleCount:number, windowHours:number}} [options.dailyLimit] - Caps completed RESULT CYCLES per window (default 1 per 24h; 0 disables).
   * @param {string} [options.embedOrigin] - Overrides the constructor default for this link.
   * @param {{displayName?:string, industry?:string, designation?:string, language?:string}} [options.metadata]
   * @returns {Promise<{quizLink: string, expiresInSeconds: number, embedOrigin: string|null}>}
   */
  async initiate(userId, options = {}) {
    if (!userId || typeof userId !== "string") {
      throw new TypeError("MayamayaQuizClient#initiate: userId is required");
    }

    const resultsWebhookUrl = options.resultsWebhookUrl ?? this.#defaultResultsWebhookUrl;
    // Caught here rather than as a 400 round-trip: this is a misconfiguration, and
    // the message can say where to fix it.
    if (!resultsWebhookUrl || typeof resultsWebhookUrl !== "string") {
      throw new TypeError(
        "MayamayaQuizClient#initiate: resultsWebhookUrl is required -- set it on the constructor or pass it per call. Quiz results are delivered by webhook; there is nowhere to send them without it."
      );
    }

    const body = {
      userId,
      resultsWebhookUrl,
      userType: options.userType ?? this.#defaultUserType,
      dailyLimit: options.dailyLimit ?? this.#defaultDailyLimit,
      // Absent => popup/redirect link, which the hosted page refuses to render in a
      // frame. That default is deliberate: framing has to be opted into by the
      // server that holds the API key, never inferred.
      embedOrigin: options.embedOrigin ?? this.#defaultEmbedOrigin,
      metadata: options.metadata,
    };
    for (const key of Object.keys(body)) {
      if (body[key] === undefined) delete body[key];
    }

    const response = await this.#request("POST", INITIATE_PATH, body);
    return response.data;
  }

  /** Sanity-checks that your API key is valid and which services it can access. */
  async verifyKey() {
    const response = await this.#request("GET", VERIFY_KEY_PATH);
    return response.data;
  }

  /**
   * Where a user is up to.
   *
   * `status` is one of `not_started`, `in_progress`, `cycle_completed`,
   * `delivery_pending`, `delivery_failed`. The last two are `cycle_completed` with
   * the delivery state overlaid; `delivery` carries the detail either way, so a
   * failure stays visible after the status has moved on.
   *
   * Cheap enough to poll. Throws MayamayaQuizError with `.status === 404` if you
   * have never called `initiate` for this user.
   *
   * @param {string} userId
   * @returns {Promise<object>}
   */
  async getUserStatus(userId) {
    requireUserId(userId, "getUserStatus");
    const response = await this.#request("GET", userPath(userId, "/status"));
    return response.data;
  }

  /**
   * The user's most recent completed cycle, in exactly the shape the results webhook
   * delivered — same builder on our side, so the two cannot drift.
   *
   * This is the recovery path for a delivery you missed, not a replacement for the
   * webhook: it tells you nothing about *when* a cycle completed unless you poll.
   *
   * Throws MayamayaQuizError with `.status === 404` if they have not completed one.
   *
   * @param {string} userId
   * @returns {Promise<object>}
   */
  async getLatestResults(userId) {
    requireUserId(userId, "getLatestResults");
    const response = await this.#request("GET", userPath(userId, "/results/latest"));
    return response.data;
  }

  /**
   * Which cycles this user has completed — `{ cycleNumber, sprintNumber, completedAt }`
   * each, oldest first. Metadata only; fetch one with `getResultsForCycle`.
   *
   * @param {string} userId
   * @returns {Promise<{userId: string, cycles: object[]}>}
   */
  async getResultCycles(userId) {
    requireUserId(userId, "getResultCycles");
    const response = await this.#request("GET", userPath(userId, "/results/cycles"));
    return response.data;
  }

  /**
   * One specific cycle in full, including its `changeFromPreviousCycle` block.
   *
   * @param {string} userId
   * @param {number} cycleNumber - 1-based
   * @returns {Promise<object>}
   */
  async getResultsForCycle(userId, cycleNumber) {
    requireUserId(userId, "getResultsForCycle");
    if (!Number.isInteger(cycleNumber) || cycleNumber < 1) {
      throw new TypeError("MayamayaQuizClient#getResultsForCycle: cycleNumber must be a positive integer");
    }
    const response = await this.#request("GET", userPath(userId, `/results/cycles/${cycleNumber}`));
    return response.data;
  }

  /**
   * Re-send a results webhook you already have an id for — for when your endpoint
   * was down past our retry ladder, or your handler dropped an event it had already
   * acknowledged.
   *
   * The ORIGINAL payload is re-sent unchanged, under the same event id, so your
   * existing idempotency handling still recognises it. Resolves once the attempt has
   * been made: `status` is `"delivered"` or `"pending"`, and a `"pending"` result
   * means your endpoint refused it and it has re-entered the retry ladder.
   *
   * @param {string} eventId - the `id` from the event envelope
   * @returns {Promise<{redelivered: boolean, eventId: string, status?: string, lastError?: string|null}>}
   */
  async redeliverEvent(eventId) {
    if (!eventId || typeof eventId !== "string") {
      throw new TypeError("MayamayaQuizClient#redeliverEvent: eventId is required");
    }
    const response = await this.#request("POST", `${MMQUIZZES_BASE}/events/${encodeURIComponent(eventId)}/redeliver`);
    return response.data;
  }

  /**
   * Verifies an inbound results webhook and returns the parsed event, using this
   * client's own API key as the signing key. Throws MayamayaWebhookError if the
   * delivery doesn't verify -- respond 400 and do nothing in that case.
   *
   * `rawBody` must be the UNPARSED request body (string or Buffer). See the README
   * for how to keep it raw in Express.
   *
   *   const event = quizClient.constructWebhookEvent(req.body, req.headers);
   *   if (event.type === "mmQuizzes.results.completed") { ... }
   *
   * @param {string|Buffer} rawBody
   * @param {object} headers
   * @returns {{id: string, type: string, createdAt: string, orgId: string, data: object}}
   */
  constructWebhookEvent(rawBody, headers) {
    return constructEvent({ payload: rawBody, headers, apiKey: this.#apiKey });
  }

  async #request(method, path, body) {
    let res;
    try {
      res = await fetch(`${this.#baseUrl}${path}`, {
        method,
        headers: {
          "x-api-key": this.#apiKey,
          ...(body ? { "Content-Type": "application/json" } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch (networkError) {
      throw new MayamayaQuizError(0, `Network error calling MayaMaya API: ${networkError.message}`, null);
    }

    let data = null;
    const text = await res.text();
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { message: text };
      }
    }

    if (!res.ok) {
      throw new MayamayaQuizError(res.status, data?.message || `MayaMaya API request failed (${res.status})`, data);
    }
    return data;
  }
}
