export declare const SIGNATURE_HEADER: string;
export declare const KEY_ID_HEADER: string;
export declare const EVENT_ID_HEADER: string;
export declare const EVENT_TYPE_HEADER: string;
export declare const DEFAULT_TOLERANCE_SECONDS: number;

export declare class MayamayaWebhookError extends Error {}

/**
 * One of the four life-value quads. The quad's name is the key it appears under in
 * `results`, so the object carries only its score.
 */
export interface QuadResult {
  /**
   * 1-10, two decimal places. Cumulative over the user's whole history. A quad the
   * user has no scored questions in yet reports a neutral default, not null; null
   * appears only in change blocks, where it means "no comparison exists".
   */
  score: number | null;
}

export interface SkillSubcategory {
  name: string;
  score: number;
}

export interface SkillCategory {
  name: string;
  score: number;
  subcategories: SkillSubcategory[];
}

export interface ResultsCompletedData {
  /** YOUR identifier for the end user -- the same string you passed to initiate(). */
  userId: string;
  /** 1 for the first set of results, 2 for the next, and so on. */
  cycleNumber: number;
  sprintNumber: number;
  /** Cumulative questions answered by this user, all time -- not just this cycle. */
  totalQuestionsAnswered: number;
  completedAt: string;
  results: {
    spirit: QuadResult;
    purpose: QuadResult;
    rewards: QuadResult;
    profession: QuadResult;
  };
  skills: SkillCategory[];
  /**
   * Movement since the previous cycle, mirroring `results`/`skills`. Null on cycle
   * 1. Within it, a score with nothing to compare against (e.g. a subcategory first
   * measured this cycle) is null -- never 0, which would read as "no change".
   */
  changeFromPreviousCycle: {
    results: {
      spirit: QuadResult;
      purpose: QuadResult;
      rewards: QuadResult;
      profession: QuadResult;
    };
    skills: Array<{
      name: string;
      score: number | null;
      subcategories: Array<{ name: string; score: number | null }>;
    }>;
  } | null;
}

export interface MayamayaWebhookEvent<T = ResultsCompletedData> {
  /** Stable across retries of the same event -- use it to deduplicate. */
  id: string;
  type: "mmQuizzes.results.completed" | (string & {});
  createdAt: string;
  orgId: string;
  data: T;
}

export interface ConstructEventArgs {
  /** The RAW request body, exactly as received. */
  payload: string | Buffer;
  headers?: Record<string, unknown> | Headers;
  /** Alternative to `headers`: the x-catenate-signature value on its own. */
  signature?: string;
  /** Your Service API Key. Pass an array while rotating keys -- any match verifies. */
  apiKey: string | string[];
  toleranceSeconds?: number;
}

export declare function webhookSigningKey(apiKey: string): string;
export declare function constructEvent(args: ConstructEventArgs): MayamayaWebhookEvent;
export declare function verifyWebhookSignature(args: ConstructEventArgs): boolean;
