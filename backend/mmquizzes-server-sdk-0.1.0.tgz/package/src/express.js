// Optional Express adapter. Not imported by the package's main entry point, so
// Express is never a required dependency -- only pull this in if you use it:
//   import { createInitiateHandler } from "mmquizzes-server-sdk/express";

/**
 * Builds an Express route handler that calls quizClient.initiate() and responds
 * with { quizLink, expiresInSeconds } as JSON -- the exact shape mmquizzes-embed-sdk
 * expects from your endpoint.
 *
 * @example
 *   app.post("/start-quiz", createInitiateHandler(
 *     quizClient,
 *     (req) => req.session.userId,
 *     (req) => ({ metadata: { industry: req.session.org.industry } }) // optional
 *   ));
 *
 * @param {import("./index.js").MayamayaQuizClient} quizClient
 * @param {(req: any) => (string | Promise<string>)} getUserId - Resolve YOUR user id from the request (session, auth middleware, etc.)
 * @param {(req: any) => (object | Promise<object>)} [getOptions] - Optional per-request initiate() options
 */
export function createInitiateHandler(quizClient, getUserId, getOptions) {
  if (typeof getUserId !== "function") {
    throw new TypeError("createInitiateHandler: getUserId(req) function is required");
  }

  return async function initiateHandler(req, res) {
    try {
      const userId = await getUserId(req);
      if (!userId) {
        res.status(400).json({ message: "Could not resolve a userId for this request" });
        return;
      }

      const options = getOptions ? await getOptions(req) : undefined;
      const result = await quizClient.initiate(userId, options);
      res.json(result);
    } catch (error) {
      const status = Number.isInteger(error?.status) && error.status >= 400 && error.status < 600 ? error.status : 500;
      res.status(status).json({ message: error?.message || "Failed to initiate quiz" });
    }
  };
}

/**
 * Builds an Express route handler that verifies an inbound results webhook and
 * hands you the parsed event.
 *
 * Mount it with `express.raw()`, NOT `express.json()` -- the signature covers the
 * exact bytes we sent, and re-serializing parsed JSON can reorder keys or change
 * whitespace, which breaks verification:
 *
 *   app.post(
 *     "/mayamaya-webhook",
 *     express.raw({ type: "application/json" }),
 *     createWebhookHandler(quizClient, async (event) => {
 *       if (event.type === "mmQuizzes.results.completed") {
 *         await db.saveResults(event.data.userId, event.data);
 *       }
 *     })
 *   );
 *
 * Response semantics, which drive our retries:
 *   - 200 once your handler resolves -- we stop.
 *   - 400 if the signature doesn't verify -- we do NOT retry (it wouldn't help).
 *   - 500 if your handler throws -- we retry with backoff, so throwing on a
 *     transient failure (your DB is down) is the correct thing to do.
 *
 * Deliveries are at-least-once. `event.id` is stable across retries of the same
 * event -- key your writes on it (or on userId + cycleNumber) to stay idempotent.
 *
 * @param {import("./index.js").MayamayaQuizClient} quizClient
 * @param {(event: object, req: any) => (void | Promise<void>)} onEvent
 */
export function createWebhookHandler(quizClient, onEvent) {
  if (typeof onEvent !== "function") {
    throw new TypeError("createWebhookHandler: onEvent(event) function is required");
  }

  return async function webhookHandler(req, res) {
    // express.raw() gives a Buffer; a raw-body middleware may leave req.rawBody
    // instead. Anything already parsed into an object can't be verified.
    const rawBody = Buffer.isBuffer(req.body) ? req.body : (req.rawBody ?? req.body);
    if (typeof rawBody !== "string" && !Buffer.isBuffer(rawBody)) {
      res.status(400).json({
        message: "Webhook body was already parsed. Mount this handler with express.raw({ type: 'application/json' }) so the raw bytes survive for signature verification.",
      });
      return;
    }

    let event;
    try {
      event = quizClient.constructWebhookEvent(rawBody, req.headers);
    } catch (error) {
      res.status(400).json({ message: error?.message || "Invalid webhook signature" });
      return;
    }

    try {
      await onEvent(event, req);
      res.status(200).json({ received: true });
    } catch (error) {
      // 5xx so the delivery is retried rather than silently dropped.
      res.status(500).json({ message: error?.message || "Webhook handler failed" });
    }
  };
}
