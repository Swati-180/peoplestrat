import type { MayamayaWebhookEvent } from "./webhooks.js";

export type UserType = "Professional" | "Student";

export interface DailyLimit {
  /**
   * How many completed RESULT CYCLES this user may produce per window — not
   * questions. Server default 1; `0` disables the cap entirely.
   */
  cycleCount: number;
  windowHours: number;
}

export type AssessmentStatus =
  | "not_started"
  | "in_progress"
  | "cycle_completed"
  | "delivery_pending"
  | "delivery_failed";

export interface DeliveryState {
  eventId: string;
  status: "pending" | "delivered" | "failed";
  attempts: number;
  maxAttempts: number;
  /** Only while another attempt is still coming. */
  nextAttemptAt: string | null;
  deliveredAt: string | null;
  lastError: string | null;
}

export interface UserAssessmentStatus {
  userId: string;
  status: AssessmentStatus;
  /** Cumulative across every cycle, not just the current one. */
  questionsAnswered: number;
  /** Remaining in the cycle currently open. */
  questionsRemaining: number;
  /** 1-based, and always the cycle IN PROGRESS. */
  currentCycle: number;
  cyclesCompleted: number;
  lastActivityAt: string | null;
  /** When the most recent cycle closed; null until the first one does. */
  completedAt: string | null;
  limit: { blocked: boolean; remaining: number | null; resumesAt: string | null };
  delivery: DeliveryState | null;
}

export interface QuadScore {
  score: number | null;
}

export interface SkillCategoryScore {
  name: string;
  score: number | null;
  subcategories: Array<{ name: string; score: number | null }>;
}

/**
 * One completed cycle. `results` and `skills` are CUMULATIVE — recomputed over
 * every question the user has ever answered, not just this cycle's 27.
 */
export interface CycleResults {
  userId: string;
  cycleNumber: number;
  sprintNumber: number;
  /** Always `27 * cycleNumber`, and stable for a given cycle forever. */
  totalQuestionsAnswered: number;
  completedAt: string;
  results: { spirit: QuadScore; purpose: QuadScore; rewards: QuadScore; profession: QuadScore };
  skills: SkillCategoryScore[];
  /**
   * Movement since the previous cycle, mirroring `results`/`skills` exactly.
   * `null` on cycle 1. Within it, any score with nothing to compare against is
   * `null` — never 0, which would read as "no change".
   */
  changeFromPreviousCycle: {
    results: { spirit: QuadScore; purpose: QuadScore; rewards: QuadScore; profession: QuadScore };
    skills: SkillCategoryScore[];
  } | null;
}

export interface CycleSummary {
  cycleNumber: number;
  sprintNumber: number;
  completedAt: string;
}

export interface RedeliverResult {
  redelivered: boolean;
  eventId: string;
  attempted?: boolean;
  status?: "delivered" | "pending" | "failed" | null;
  lastResponseStatus?: number | null;
  lastError?: string | null;
}

export interface QuizMetadata {
  displayName?: string;
  industry?: string;
  designation?: string;
  language?: string;
}

export interface MayamayaQuizClientOptions {
  /** Your Service API Key (Dashboard -> API Keys). Server-side only, never expose to the browser. */
  apiKey: string;
  /** Override the MayaMaya API host. Rarely needed; for pointing at a local backend. */
  baseUrl?: string;
  /**
   * Where completed results are POSTed. Required on every initiate() call, so set
   * it here once unless it varies per user. Unlike userType/dailyLimit it is NOT
   * frozen -- each call updates the destination for that user.
   */
  resultsWebhookUrl?: string;
  /** Default userType for every initiate() call; overridable per call. Only takes effect on a user's first-ever call. */
  userType?: UserType;
  /** Default dailyLimit for every initiate() call; overridable per call. Only takes effect on a user's first-ever call. */
  dailyLimit?: DailyLimit;
  /**
   * Origin of YOUR page that will host the quiz in an iframe, e.g.
   * "https://app.example.com" -- an origin, not a URL: no path, query or fragment.
   *
   * Required for embedded mode (mountQuiz() in mmquizzes-embed-sdk). Omit it and the
   * link is popup/redirect-only: the quiz will refuse to render inside any frame.
   * Declare it here, on your server -- an origin supplied by the page being framed
   * would check nothing.
   */
  embedOrigin?: string;
}

export interface InitiateOptions {
  /** Overrides the client's default destination for this user. */
  resultsWebhookUrl?: string;
  userType?: UserType;
  dailyLimit?: DailyLimit;
  /** Overrides the client's default embed origin for this link. */
  embedOrigin?: string;
  metadata?: QuizMetadata;
}

export interface InitiateResult {
  quizLink: string;
  expiresInSeconds: number;
  /** The origin this link may be framed by, or null if it is popup/redirect-only. */
  embedOrigin: string | null;
}

export interface VerifyKeyResult {
  orgId: string;
  services: string[];
}

export declare class MayamayaQuizError extends Error {
  status: number;
  body: unknown;
}

export declare class MayamayaQuizClient {
  constructor(options: MayamayaQuizClientOptions);
  initiate(userId: string, options?: InitiateOptions): Promise<InitiateResult>;
  verifyKey(): Promise<VerifyKeyResult>;
  /** Where a user is up to. Throws MayamayaQuizError (404) if never initiated. */
  getUserStatus(userId: string): Promise<UserAssessmentStatus>;
  /** Most recent completed cycle. Throws MayamayaQuizError (404) if there is none. */
  getLatestResults(userId: string): Promise<CycleResults>;
  /** Which cycles exist, oldest first. Metadata only. */
  getResultCycles(userId: string): Promise<{ userId: string; cycles: CycleSummary[] }>;
  /** One cycle in full, including its change block. */
  getResultsForCycle(userId: string, cycleNumber: number): Promise<CycleResults>;
  /** Re-send a results webhook by its stable event id, payload unchanged. */
  redeliverEvent(eventId: string): Promise<RedeliverResult>;
  /** Verifies an inbound results webhook with this client's API key and returns the parsed event. */
  constructWebhookEvent(rawBody: string | Buffer, headers: Record<string, unknown>): MayamayaWebhookEvent;
}

export {
  MayamayaWebhookError,
  constructEvent,
  verifyWebhookSignature,
  webhookSigningKey,
} from "./webhooks.js";
export type {
  MayamayaWebhookEvent,
  ResultsCompletedData,
  QuadResult,
  SkillCategory,
  SkillSubcategory,
} from "./webhooks.js";
