import type { MayamayaWebhookEvent } from "./webhooks.js";

export type UserType = "Professional" | "Student";

export interface DailyLimit {
  questionCount: number;
  windowHours: number;
}

export interface QuizMetadata {
  displayName?: string;
  industry?: string;
  designation?: string;
  language?: string;
}

export interface MayamayaQuizClientOptions {
  /** Your Service API Key (Dashboard -> API Keys). Server-side only, never expose to the browser. */
  apiKey: string;
  /** Override the MayaMaya API host. Rarely needed; for pointing at a local backend. */
  baseUrl?: string;
  /**
   * Where completed results are POSTed. Required on every initiate() call, so set
   * it here once unless it varies per user. Unlike userType/dailyLimit it is NOT
   * frozen -- each call updates the destination for that user.
   */
  resultsWebhookUrl?: string;
  /** Default userType for every initiate() call; overridable per call. Only takes effect on a user's first-ever call. */
  userType?: UserType;
  /** Default dailyLimit for every initiate() call; overridable per call. Only takes effect on a user's first-ever call. */
  dailyLimit?: DailyLimit;
}

export interface InitiateOptions {
  /** Overrides the client's default destination for this user. */
  resultsWebhookUrl?: string;
  userType?: UserType;
  dailyLimit?: DailyLimit;
  metadata?: QuizMetadata;
}

export interface InitiateResult {
  quizLink: string;
  expiresInSeconds: number;
}

export interface VerifyKeyResult {
  orgId: string;
  services: string[];
}

export declare class MayamayaQuizError extends Error {
  status: number;
  body: unknown;
}

export declare class MayamayaQuizClient {
  constructor(options: MayamayaQuizClientOptions);
  initiate(userId: string, options?: InitiateOptions): Promise<InitiateResult>;
  verifyKey(): Promise<VerifyKeyResult>;
  /** Verifies an inbound results webhook with this client's API key and returns the parsed event. */
  constructWebhookEvent(rawBody: string | Buffer, headers: Record<string, unknown>): MayamayaWebhookEvent;
}

export {
  MayamayaWebhookError,
  constructEvent,
  verifyWebhookSignature,
  webhookSigningKey,
} from "./webhooks.js";
export type {
  MayamayaWebhookEvent,
  ResultsCompletedData,
  QuadResult,
  SkillCategory,
  SkillSubcategory,
} from "./webhooks.js";
