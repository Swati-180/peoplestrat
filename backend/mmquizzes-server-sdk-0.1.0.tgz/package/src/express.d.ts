import type { MayamayaQuizClient, InitiateOptions } from "./index.js";
import type { MayamayaWebhookEvent } from "./webhooks.js";

export declare function createInitiateHandler(
  quizClient: MayamayaQuizClient,
  getUserId: (req: any) => string | Promise<string>,
  getOptions?: (req: any) => InitiateOptions | Promise<InitiateOptions>
): (req: any, res: any) => Promise<void>;

/**
 * Mount with express.raw({ type: "application/json" }) -- the signature covers the
 * raw bytes, so the body must not be parsed before it reaches this handler.
 */
export declare function createWebhookHandler(
  quizClient: MayamayaQuizClient,
  onEvent: (event: MayamayaWebhookEvent, req: any) => void | Promise<void>
): (req: any, res: any) => Promise<void>;
